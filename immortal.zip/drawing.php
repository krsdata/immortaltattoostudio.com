<?php include_once('header.php'); ?>

	<div class="panel-3" style="height:auto">
		<div class="faq-main">
			<h2 class="page-title">Drawing & Sketches</h2>
			<p class="fq">
				The art of drawing sketches is at the core of every effective figurative image, Sketch with Expression and Power.
				<ul style="width:50%; float:left">
                <li>Sketching Techniques: Speed</li>
                <li>Sketching Techniques: Contrapposto</li>
                <li>Sketching Techniques: The Line of Gravity</li>
                <li>Sketching Techniques: Rhythm</li>
                <li>Sketching Techniques: Line Quality</li>
                <li>Sketching Techniques: Foreshortening</li>
                <li>Sketching Techniques: Positive Shapes vs. Negative Shapes</li>
                <li>Sketching Techniques: Concepts and Composition</li>
                <li>Sketching Techniques: Long-Term Drawing</li>
			    </ul>
				  <ul style="width:50%; float:left;margin-bottom: -18px;"><img src="images/sk.jpg" width="100%" /></ul>
			</p>	
        </div>
	</div> 

<?php include_once('footer.php'); ?>

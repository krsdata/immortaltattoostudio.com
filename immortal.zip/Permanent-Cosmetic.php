<?php include_once('header.php'); ?>

	<div class="panel-3" style="height:auto">
		<div class="faq-main">
		<div style="width:50%; float:left">
			<h2 class="page-title">Permanent Cosmetic Make-Up
</h2>
			<p class="fq">
				If you are searching for permanent makeup schools, you have come to the right place. 
Permanent cosmetics is a unique and growing industry. Becoming a professional permanent makeup artist can be a rewarding career move for anyone interested in becoming a cosmetic artist or for those who want to advance their career in the beauty business. 
                        </p>	
       </div>
	 
		<div  style="width:45%; float:left;margin-top: 31px;margin-bottom: -14px;margin-left: 20px;"> <img src="images/permanent.jpg" width="500px" /> </div>
	</div> 
	</div>

<?php include_once('footer.php'); ?>

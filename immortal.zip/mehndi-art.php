<?php include_once('header.php'); ?>

	<div class="panel-3" style="height:auto">
		<div class="faq-main">
			<h2 class="page-title">Mehendi Art</h2>
			<p class="fq">
				It goes that Knowledge grows by sharing; I consider it my pleasure to share my skills with individuals interested and learning the art of Mehendi Design. Students showing exceptional talent are extended an offer to be a part of my team. Personal attention will be given to all students at all times 
				<br/><span style="margin-top:15px;margin-bottom:15px;float:left;width:100%;">The Main Courses Are:</span>
				
				<ul style="width:50%; float:left">
				<li>Basic Mehendi</li>
                <li>Arabic Mehndi</li>
                <li>Indian Mehendi</li>
                <li>Bridal Mahendi</li>
                <li>Advance Arabic Mehendi</li>
                <li>Advance Bridal Mehndi</li>
                <li>Dubai</li>
                <li>Rose mehendi & Many More</li>
              </ul>
			  <ul style="width:50%; float:left"><img src="images/mehndi.png" width="500px" /></ul>
			</p>	
        </div>
	</div> 

<?php include_once('footer.php'); ?>

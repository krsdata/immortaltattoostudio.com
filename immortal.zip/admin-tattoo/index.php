<?php
header('location:manage-user.php');?>
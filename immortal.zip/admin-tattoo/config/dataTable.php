<?php
	define('TBL_USER','users');
	define('TBL_ADMIN','tbl_admin');
	define('TBL_PAGE','tbl_pages');
 
	define('TBL_CLIENT_CASE','gallery');
	
	
	
?>
<div class="footer">
			 
			<ul>
			<b>
			<li class="f-menu"> <a href="index.php">HOME</a></li> | <li class="f-menu"><a href="about.php">ABOUT US</a></li> | <li class="f-menu"><a href="gallery.php">gallery</a></li> | 
			<li class="f-menu"><a href="#">training</a></li> | <li class="f-menu"><a href="faq.php">FAQ</a> </li> | <li class="f-menu"><a href="contact.php">Contact us</a></li> 
			</b>
			</ul>
			 
		</div>
</div>

<link rel="stylesheet" href="style/colorbox.css" />
<script src="js/jquery.colorbox.js"></script>
  <script>
			$(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements
			$(".group1").colorbox({rel:'group1', slideshow:true, width:"65%", height:"75%"});
				
			 
			});
		</script>
</body>
</html>
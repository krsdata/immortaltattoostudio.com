<?php include_once('header.php'); ?>
<style>
.fq{ font-family:"blackchanceryregular";}
</style>
	<div class="panel-3" style="height:auto">
		<div class="faq-main">
			<h2 class="page-title">About Us</h2>
			<p class="fq">
				I am Dina-Karan from Bangalore, I have 7 years experience in tattoo field I love to do larger black & gray pieces as well as crazy color blending. I give 110% on every tattoo no matter how big or small it may be. my customers satisfaction is my main focus and I want to help you design your tattoo and take your idea to the next level. Behind and your imagination, the job is watching your excitement the first time you look at your new tattoo in the mirror.... 
			</p>
			<p class="fq">
				Immortal Creative Tattoo Studio & Academy has wanted to differentiate itself from other tattoo studios. It is our focus to provide customers with artistic tattooing, whether it is a custom designed piece, freehand artwork, or traditional wall flash. We have in the past and continue in the future to treat our clients with respect and dignity. We maintain our studios with the utmost cleanliness.	
			</p>
			<p class="fq">
       			Immortal Creative Tattoo Studio & Academy now has four convenient locations to serve all of your tattoo and piercing needs located in Lg-1, Diamond Colony, Opposite Bansi Trade Center, Mg Road, Indore. Whether you are looking to get your first tattoo or piercing, coverup an old tattoo, or just add some new work to what you already have… Don’t sacrifice on something that will be with you for the rest of your life… Look no further than Immortal Creative Tattoo Studio & Academy for the true Tattoo and Tattoo Training experts,
			</p>	
        </div>
	</div> 

<?php include_once('footer.php'); ?>

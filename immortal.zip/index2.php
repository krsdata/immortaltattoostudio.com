<?php include_once('header.php'); ?>

<div class="panel-3">
	<div class="get_tattoo_deserv">
			<div class="get_tattoo" align="right">
			<img width="401" height="111" src="images/get_tattoo.jpg">
				<div class="jcarousel-wrapper">
                <div class="jcarousel">
                    <ul>
                        <li><img src="images/tat1.jpg" alt="Image 1"></li>
                        <li><img src="images/tat2.jpg" alt="Image 2"></li>
                        <li><img src="images/tat3.jpg" alt="Image 3"></li>
                        <li><img src="images/tat4.jpg" alt="Image 4"></li>
                        <li><img src="images/tat1.jpg" alt="Image 5"></li>
                        <li><img src="images/tat2.jpg" alt="Image 6"></li>
                    </ul>
                </div>

                <a href="#" class="jcarousel-control-prev">&lsaquo;</a>
                <a href="#" class="jcarousel-control-next">&rsaquo;</a>

                <!-- <p class="jcarousel-pagination"></p> -->
            </div>
			</div>	
			</div>
		</div>
		
		<div class="panel-4">
		 	
		</div>
		
		<div class="our-tattoo panel-5">
			<span style="color:rgb(134, 107, 86);">Our </span>  Tattoos </span> <span style="font-family: blackchancery; font-size: 30px;"> (First tattooist in MP)</span> 
		</div>
		<div class="abt-tattoo">
			<p align="justify">
				 I am Dina-Karan from Bangalore, I have 6 years experience in tattoo field I love to do larger black & gray pieces as well as crazy color blending. I give 110% on every tattoo no matter how big or small it may be. my customers satisfaction is my main focus and I want to help you design your tattoo and take your idea to the next level. Behind and your imagination, the job is watching your excitement the first time you look at your new tattoo in the mirror.
			</p>
		</div>
		
		<div class="panel-6">
				<a href="gallery.html"><p align="right" class="go-to-gall"> <strong style="color: rgb(255, 255, 255);">GO TO OUR</strong> <strong style="color: rgb(185, 148, 122);">GALLERY </strong></p></a>
		</div>
<?php include_once('footer.php'); ?>		
<?php include_once('header.php'); ?>
<?php 
$sql = mysql_query("select * from gallery order by id DESC limit 12");
?>
	<style>
	.image img {
  height: 170px;
  width: 100%;
}
	</style>
		<div class="panel-3" style="height:auto">
			<div class="faq-main">
				<h2 class="page-title">Gallery</h2>
					<div class="grid-list-tattoo">
						<?php 
							while($row =  mysql_fetch_array($sql))
							{
							
						?>
						<div class="image">
				        <a href="admin-tattoo/uploads/<?php echo $row['file_name']; ?>" title="" class="group1">
				        <img src="admin-tattoo/uploads/<?php echo $row['file_name']; ?>">				
				        </a>
				        </div>
						<?php } ?>
					</div>	
</div>
		</div>
		
		
	
		
		<div class="our-tattoo panel-5" align="center">
			 Our   Tattoos 
		</div> 
		 
<?php include_once('footer.php'); ?>		
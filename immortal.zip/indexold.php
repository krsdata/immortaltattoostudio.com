<?php include_once('header.php'); ?>

<div class="panel-3" style="height:500px">
	<div class="get_tattoo_deserv" style="width:980px">
		<div style="float:left; margin-top:-100px; margin-right:10px; margin-left:-50px" > 
			<img src="images/final13.png" width="500"  height="600"/>
		</div>
			<div class="get_tattoo" align="right" style="width:450px; margin-right:0px;">
			<img width="401" height="111" src="images/get_tattoo.jpg">
				<div class="jcarousel-wrapper" style="width:458px; padding:10px; padding-right:0px; ">
                <div class="jcarousel">
                    <ul>
                        <li><img src="images/tag1.jpg" alt="Image 1"></li>
                       
                        <li><img src="images/tag3.jpg" alt="Image 3"></li>
                        <li><img src="images/tag4.jpg" alt="Image 4"></li>
                        <li><img src="images/tag1.jpg" alt="Image 5"></li>
                     
                    </ul>
                </div> 

                <a href="#" class="jcarousel-control-prev">&lsaquo;</a>
                <a href="#" class="jcarousel-control-next">&rsaquo;</a>

                <!-- <p class="jcarousel-pagination"></p> -->
            </div>
			<div align="justify" style="font-family:BlackChancery; font-size:17px;">
			 The company's main focus is tattooing, but artists work in other mediums such as: Tattoo Training, Nail Art, Permanent cosmetic make-up, charcoal, pencil drawings, and Mehndi.We are a artists with a full range of talents, whose specialty is keeping customers happy.
			<a href="#">Read More..</a>
			</div>
			<div>  
			<a href="https://www.facebook.com/immortalcreativestudio" target="_blank"><img src="img/f3.png" width="48" /></a>
			<a href="https://plus.google.com/+DinaKaranimmortalcreativetattoostudio" target="_blank"><img src="img/g6.png" width="48" /></a>
			<a href="https://twitter.com/Karan_Immortal"><img src="img/t4.png" width="48" /></a>

			</div>
			</div>	
			</div>
		</div>
		
		<div class="panel-4">
		 	
		</div>
		
		<div class="our-tattoo panel-5">
			<span style="color:rgb(134, 107, 86);">Our </span>  Tattoos </span> <span style="font-family: blackchancery; font-size: 30px;"> (First tattooist in MP)</span> 
		</div>
		<div class="abt-tattoo">
			<p align="justify">
				 I am Dina-Karan from Bangalore, I have 6 years experience in tattoo field I love to do larger black & gray pieces as well as crazy color blending. I give 110% on every tattoo no matter how big or small it may be. my customers satisfaction is my main focus and I want to help you design your tattoo and take your idea to the next level. Behind and your imagination, the job is watching your excitement the first time you look at your new tattoo in the mirror.
			</p>
		</div>
		
		<div class="panel-6">
				<a href="gallery.html"><p align="right" class="go-to-gall"> <strong style="color: rgb(255, 255, 255);">GO TO OUR</strong> <strong style="color: rgb(185, 148, 122);">GALLERY </strong></p></a>
		</div>
<?php include_once('footer.php'); ?>		
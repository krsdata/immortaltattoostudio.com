<?php include_once('header.php'); ?>

	<div class="panel-3" style="height:auto">
		<div class="faq-main" >
		<div style="width:66%; float:left">
			<h2 class="page-title">Nail Art</h2>
			<p class="fq" >
				Gel nail art and design is the latest trend in the world of nail art and nail enhancements. In principle gel art and design is an achievable procedure. Any design once placed onto an uncured gel colour coating will be able to be dragged using a gel art striper brush into the most intricate of patterns.
                        </p>
                        <p class="fq">       
His Professional Gel Art and Design programme is an in-depth step by step course that is designed to teach the student how to carry out gel art and design procedures. Throughout the course detailed examples and diagrams are provided showing the student how to create a range of beautiful gel designs.			</p>	
        </div>
		
		<div  style="width:30%; float:left;margin-top: 55px;margin-left: 20px;"> <img src="images/nail.png" width="300px" /> </div>
	</div> 
	</div>

<?php include_once('footer.php'); ?>
